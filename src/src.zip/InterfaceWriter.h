#ifndef INTERFACE_WRITER_H
#define INTERFACE_WRITER_H

struct Global;

void  writeInterface 

(       Global&  global,
  const char*    fileName );


#endif
